#include "../inc/validate_receive_data.h"

void memory_allocation_failed() {
    mx_printerr("Memory allocation failed!\n");
    exit(1);
}

void free_islands_indices(s_islandsBridgesData *data) {
    if (data->islands_indeces != NULL) {
        for (int i = 0; i < data->number_of_islands; i++) {
            free(data->islands_indeces[i]);
        }
        free(data->islands_indeces);
    }
}

void free_bridges_matrix(s_islandsBridgesData *data) {
    if (data->bridges != NULL) {
        for (int i = 0; i < data->number_of_islands; i++) {
            free(data->bridges[i]);
        }
        free(data->bridges);
    }
}

void free_islands_bridges_data(s_islandsBridgesData *data) {
    if (data == NULL) return;
    free_islands_indices(data);
    free_bridges_matrix(data);
    free(data);
}

void allocate_islands_indices(s_islandsBridgesData *data) {
    data->islands_indeces = calloc(data->number_of_islands, sizeof(char *));
    if (data->islands_indeces == NULL) {
        memory_allocation_failed();
    }
}

void allocate_bridges_matrix(s_islandsBridgesData *data) {
    data->bridges = calloc(data->number_of_islands, sizeof(int *));
    if (data->bridges == NULL) {
        free_islands_indices(data);
        memory_allocation_failed();
    }

    for (int i = 0; i < data->number_of_islands; i++) {
        data->bridges[i] = calloc(data->number_of_islands, sizeof(int));
        if (data->bridges[i] == NULL) {
            for (int j = 0; j < i; j++) {
                free(data->bridges[j]);
            }
            free(data->bridges);
            free_islands_indices(data);
            memory_allocation_failed();
        }
    }
}

void allocate_memory_for_data(s_islandsBridgesData *data) {
    allocate_islands_indices(data);
    allocate_bridges_matrix(data);
}


bool validate_receive_data(char **file_content, s_islandsBridgesData *data) {
    if (!validate_first_line(data, file_content[0])) {
        return false;
    }

    allocate_memory_for_data(data);

    if (!parse_islands_and_bridges(data, file_content)) {
        return false;
    }

    return true;
}











