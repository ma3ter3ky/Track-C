#include "../inc/input_data_from_file.h"

int input_data_from_file(int argc, char **argv, s_islandsBridgesData *data) {
    if (file_error_handling(argc, argv)) {
        return 1;
    }

    char **file_content = file_content_array(argv[1]);
    if (file_content == NULL) {
        return 1;
    }

    if (!validate_receive_data(file_content, data)) {
        mx_del_strarr(&file_content);
        return 1;
    }

    mx_del_strarr(&file_content);
    return 0;
}

