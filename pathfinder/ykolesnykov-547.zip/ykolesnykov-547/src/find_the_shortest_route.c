#include "../inc/header.h"

void find_print_shortest_routes(s_islandsBridgesData *data) {
    Graph *graph = create_graph(data->number_of_islands, data->bridges, data->islands_indeces);

    for (int src = 0; src < graph->num_nodes; src++) {
        for (int dest = src + 1; dest < graph->num_nodes; dest++) {
            Paths *paths = create_paths();
            find_all_shortest_paths(graph, src, dest, paths);
            print_paths(graph, src, dest, paths);
            free_paths(paths);
        }
    }

    free_graph(graph);
}

