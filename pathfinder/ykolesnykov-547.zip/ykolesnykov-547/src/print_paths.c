#include "../inc/print_paths.h"

void swap_paths(Paths *paths, Path *prev, Path *current, Path *next) {
    if (prev) {
        prev->next = next;
    } else {
        paths->head = next;
    }
    current->next = next->next;
    next->next = current;
}


void sort_paths(Paths *paths, Graph *graph) {
    if (!paths || !paths->head) return;

    Path *current = paths->head;
    Path *prev = NULL;

    while (current) {
        Path *next = current->next;
        prev = NULL;
        while (next) {
            bool should_swap = false;

            for (int i = 0; i < next->length && i < current->length; i++) {
                if (graph->islands[current->nodes[i]] > graph->islands[next->nodes[i]]) {
                    should_swap = true;
                    break;
                } else if (graph->islands[current->nodes[i]] < graph->islands[next->nodes[i]]) {
                    break;
                }
            }

            if (should_swap) {
                swap_paths(paths, prev, current, next);
                Path *temp = current;
                current = next;
                next = temp;
            }
            prev = next;
            next = next->next;
        }
        current = current->next;
    }
}


void print_paths(Graph *graph, int src, int dest, Paths *paths) {
    sort_paths(paths, graph);
    Path *current = paths->head;
    while (current) {
        mx_printstr("========================================\n");
        mx_printstr("Path: ");
        mx_printstr(graph->islands[src]);
        mx_printstr(" -> ");
        mx_printstr(graph->islands[dest]);
        mx_printchar('\n');

        mx_printstr("Route: ");
        for (int i = 0; i < current->length; i++) {
            mx_printstr(graph->islands[current->nodes[i]]);
            if (i < current->length - 1) {
                mx_printstr(" -> ");
            }
        }
        mx_printchar('\n');

        mx_printstr("Distance: ");
        if (current->length == 2) {
            int dist = graph->adj_matrix[src][dest];
            mx_printint(dist);
            mx_printchar('\n');
        } else {
            int total_distance = 0;
            for (int i = 0; i < current->length - 1; i++) {
                int u = current->nodes[i];
                int v = current->nodes[i + 1];
                int dist = graph->adj_matrix[u][v];
                mx_printint(dist);
                total_distance += dist;
                if (i < current->length - 2) {
                    mx_printstr(" + ");
                } else if (i == current->length - 2) {
                    mx_printstr(" = ");
                }
            }
            mx_printint(total_distance);
            mx_printchar('\n');
        }
        mx_printstr("========================================\n");
        current = current->next;
    }
}

