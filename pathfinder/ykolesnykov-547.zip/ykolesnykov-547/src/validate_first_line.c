#include "../inc/validate_first_line.h"

bool validate_first_line(s_islandsBridgesData *data, const char *line) {
    if (!line || !*line) {
        mx_printerr("error: line 1 is not valid\n");
        return false;
    }

    for (int i = 0; line[i]; i++) {
        if (!mx_isdigit(line[i])) {
            mx_printerr("error: line 1 is not valid\n");
            return false;
        }
        if (i == 0 && line[i] == '0') {
            mx_printerr("error: line 1 is not valid\n");
            return false;
        }
    }

    int number_of_islands = mx_atoi(line);
    if (number_of_islands <= 0) {
        mx_printerr("error: line 1 is not valid\n");
        return false;
    }

    data->number_of_islands = number_of_islands;
    data->actual_number_of_islands = 0;
    return true;
}







