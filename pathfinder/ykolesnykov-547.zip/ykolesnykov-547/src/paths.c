#include "../inc/paths.h"

Paths *create_paths() {
    Paths *paths = (Paths *)malloc(sizeof(Paths));
    if (!paths) return NULL;
    paths->head = NULL;
    paths->tail = NULL;
    return paths;
}

void add_path(Paths *paths, int *nodes, int length) {
    Path *path = (Path *)malloc(sizeof(Path));
    if (!path) return;
    path->nodes = (int *)malloc(length * sizeof(int));
    if (!path->nodes) {
        free(path);
        return;
    }
    for (int i = 0; i < length; i++) {
        path->nodes[i] = nodes[i];
    }
    path->length = length;
    path->next = NULL;

    if (paths->head == NULL) {
        paths->head = paths->tail = path;
    } else {
        paths->tail->next = path;
        paths->tail = path;
    }
}



void free_paths(Paths *paths) {
    Path *current = paths->head;
    while (current) {
        Path *next = current->next;
        free(current->nodes);
        free(current);
        current = next;
    }
    free(paths);
}

