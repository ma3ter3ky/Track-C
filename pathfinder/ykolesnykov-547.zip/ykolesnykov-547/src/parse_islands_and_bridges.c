#include "../inc/parse_islands_and_bridges.h"

bool mx_str_isalpha(const char *str) {
    if (str == NULL) return false;
    for (int i = 0; str[i]; i++) {
        if (!mx_isalpha(str[i])) {
            return false;
        }
    }
    return true;
}

bool check_consecutive_delimiters(const char *s, char delimiter) {
    if (s == NULL) return false;
    while (*s) {
        if (*s == delimiter && *(s + 1) == delimiter) {
            return true;
        }
        s++;
    }
    return false;
}


bool validate_line_format(const char *line) {
    if (line == NULL) return false;

    if (check_consecutive_delimiters(line, '-') || check_consecutive_delimiters(line, ',')) {
        return false;
    }

    char **parts = mx_strsplit(line, ',');
    if (!parts || !parts[0] || !parts[1] || parts[2]) {
        mx_del_strarr(&parts);
        return false;
    }

    char **islands = mx_strsplit(parts[0], '-');
    if (!islands || !islands[0] || !islands[1] || islands[2]) {
        mx_del_strarr(&islands);
        mx_del_strarr(&parts);
        return false;
    }

    if (!mx_str_isalpha(islands[0]) || !mx_str_isalpha(islands[1])) {
        mx_del_strarr(&islands);
        mx_del_strarr(&parts);
        return false;
    }

    if (mx_strcmp(islands[0], islands[1]) == 0) {
        mx_del_strarr(&islands);
        mx_del_strarr(&parts);
        return false;
    }

    for (int i = 0; parts[1][i]; i++) {
        if (!mx_isdigit(parts[1][i])) {
            mx_del_strarr(&islands);
            mx_del_strarr(&parts);
            return false;
        }
    }

    mx_del_strarr(&islands);
    mx_del_strarr(&parts);
    return true;
}

int find_island_index(char **islands_indices, const char *island_name, int max_islands) {
    for (int i = 0; i < max_islands; i++) {
        if (islands_indices[i] && mx_strcmp(islands_indices[i], island_name) == 0) {
            return i;
        }
    }
    return -1;
}

int add_island(s_islandsBridgesData *data, const char *island_name) {
    int index = find_island_index(data->islands_indeces, island_name, data->number_of_islands);
    if (index != -1) {
        return index;
    }

    if (data->actual_number_of_islands >= data->number_of_islands) {
        return -1;
    }

    data->islands_indeces[data->actual_number_of_islands] = mx_strdup(island_name);
    if (!data->islands_indeces[data->actual_number_of_islands]) {
        memory_allocation_failed();
    }

    index = data->actual_number_of_islands;
    data->actual_number_of_islands++;
    return index;
}

int find_or_add_island(s_islandsBridgesData *data, char *island) {
    int index = find_island_index(data->islands_indeces, island, data->number_of_islands);
    if (index != -1) {
        return index;
    }

    if (data->actual_number_of_islands >= data->number_of_islands) {
        return -1;
    }

    data->islands_indeces[data->actual_number_of_islands] = mx_strdup(island);
    index = data->actual_number_of_islands;
    data->actual_number_of_islands++;
    return index;
}

bool add_island_to_structure(s_islandsBridgesData *data, char *island1, char *island2) {
    int index1 = find_or_add_island(data, island1);
    int index2 = find_or_add_island(data, island2);

    if (index1 == -1 || index2 == -1) {
        mx_printerr("error: invalid number of islands\n");
        return false;
    }

    return true;
}


bool check_for_duplicate_bridges(int **bridges, int island1, int island2) {
    return bridges[island1][island2] != 0;
}

void update_bridge_matrix(s_islandsBridgesData *data, int index1, int index2, int length) {
    data->bridges[index1][index2] = length;
    data->bridges[index2][index1] = length;
}

bool check_bridge_sum(int total_length, int bridge_length) {
    return INT_MAX - bridge_length >= total_length;
}

bool parse_line(const char *line, s_islandsBridgesData *data, int line_number, int *total_length) {
    if (!validate_line_format(line)) {
        mx_printerr("error: line ");
        mx_printerr(mx_itoa(line_number));
        mx_printerr(" is not valid\n");
        return false;
    }

    char **parts = mx_strsplit(line, ',');
    char **islands = mx_strsplit(parts[0], '-');
    int bridge_length = mx_atoi(parts[1]);

    if (bridge_length <= 0) {
        mx_printerr("error: line ");
        mx_printerr(mx_itoa(line_number));
        mx_printerr(" is not valid\n");
        mx_del_strarr(&islands);
        mx_del_strarr(&parts);
        return false;
    }

    int index1 = add_island(data, islands[0]);
    int index2 = add_island(data, islands[1]);

    if (index1 == -1 || index2 == -1) {
        mx_printerr("error: invalid number of islands\n");
        mx_del_strarr(&islands);
        mx_del_strarr(&parts);
        return false;
    }

    if (data->bridges[index1][index2] != 0) {
        mx_printerr("error: duplicate bridges\n");
        mx_del_strarr(&islands);
        mx_del_strarr(&parts);
        return false;
    }

    if (*total_length > INT_MAX - bridge_length) {
        mx_printerr("error: sum of bridges lengths is too big\n");
        mx_del_strarr(&islands);
        mx_del_strarr(&parts);
        return false;
    }

    update_bridge_matrix(data, index1, index2, bridge_length);
    data->number_of_bridges++;
    *total_length += bridge_length;

    mx_del_strarr(&islands);
    mx_del_strarr(&parts);
    return true;
}

bool parse_islands_and_bridges(s_islandsBridgesData *data, char **file_content) {
    int total_bridge_length = 0;
    int line_number = 1;

    for (int i = 1; file_content[i]; i++) {
        line_number = i + 1;

        if (!parse_line(file_content[i], data, line_number, &total_bridge_length)) {
            return false;
        }
    }

    if (data->actual_number_of_islands != data->number_of_islands) {
        mx_printerr("error: invalid number of islands\n");
        return false;
    }

    return true;
}
