#include "../inc/graph.h"

Graph *create_graph(int num_nodes, int **adj_matrix, char **islands) {
    Graph *graph = (Graph *)malloc(sizeof(Graph));
    if (!graph) return NULL;
    graph->num_nodes = num_nodes;
    graph->adj_matrix = adj_matrix;
    graph->islands = islands;
    return graph;
}

void free_graph(Graph *graph) {
    free(graph);
}
