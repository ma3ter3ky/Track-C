#include "../inc/dijkstra.h"

typedef struct Predecessor {
    int node;
    struct Predecessor *next;
} Predecessor;

typedef struct NodeInfo {
    int distance;
    Predecessor *pred;
    Predecessor *pred_tail;
    bool visited;
} NodeInfo;

static void free_predecessors(Predecessor *pred) {
    while (pred) {
        Predecessor *next = pred->next;
        free(pred);
        pred = next;
    }
}

void add_predecessor(Predecessor **head, Predecessor **tail, int node) {
    Predecessor *pred = (Predecessor *)malloc(sizeof(Predecessor));
    if (!pred) return;
    pred->node = node;
    pred->next = NULL;

    if (*head == NULL) {
        *head = *tail = pred;
    } else {
        (*tail)->next = pred;
        *tail = pred;
    }
}



static void dfs(NodeInfo *nodes, int node, int *path_buffer, int path_length, int src, Paths *paths, Graph *graph) {
    path_buffer[path_length++] = node;
    if (node == src) {
        int *path_nodes = (int *)malloc(path_length * sizeof(int));
        if (path_nodes) {
            for (int i = 0; i < path_length; i++)
                path_nodes[i] = path_buffer[path_length - i - 1];
            add_path(paths, path_nodes, path_length);
            free(path_nodes);
        }
    } else {
        int pred_count = 0;
        Predecessor *pred = nodes[node].pred;
        while (pred) {
            pred_count++;
            pred = pred->next;
        }
        int *pred_indices = (int *)malloc(pred_count * sizeof(int));
        char **pred_names = (char **)malloc(pred_count * sizeof(char *));
        pred = nodes[node].pred;
        for (int i = 0; i < pred_count; i++) {
            pred_indices[i] = pred->node;
            pred_names[i] = graph->islands[pred->node];
            pred = pred->next;
        }
        for (int i = 0; i < pred_count - 1; i++) {
            for (int j = i + 1; j < pred_count; j++) {
                if (pred_indices[i] > pred_indices[j]) {
                    int temp_idx = pred_indices[i];
                    pred_indices[i] = pred_indices[j];
                    pred_indices[j] = temp_idx;
                    char *temp_name = pred_names[i];
                    pred_names[i] = pred_names[j];
                    pred_names[j] = temp_name;
                }
            }
        }

        for (int i = 0; i < pred_count; i++) {
            dfs(nodes, pred_indices[i], path_buffer, path_length, src, paths, graph);
        }
        free(pred_indices);
        free(pred_names);
    }
}


void find_all_shortest_paths(Graph *graph, int src, int dest, Paths *paths) {
    int n = graph->num_nodes;
    NodeInfo *nodes = (NodeInfo *)malloc(n * sizeof(NodeInfo));
    if (!nodes) return;

    for (int i = 0; i < n; i++) {
        nodes[i].distance = INT_MAX;
        nodes[i].pred = NULL;
        nodes[i].pred_tail = NULL;
        nodes[i].visited = false;
    }
    nodes[src].distance = 0;

    while (true) {
        int u = -1, min_distance = INT_MAX;
        for (int i = 0; i < n; i++) {
            if (!nodes[i].visited && nodes[i].distance < min_distance) {
                min_distance = nodes[i].distance;
                u = i;
            }
        }
        if (u == -1) break;

        nodes[u].visited = true;

        for (int v = 0; v < n; v++) {
            if (graph->adj_matrix[u][v] > 0) {
                int alt_distance = nodes[u].distance + graph->adj_matrix[u][v];
                if (alt_distance < nodes[v].distance) {
                    nodes[v].distance = alt_distance;
                    free_predecessors(nodes[v].pred);
                    nodes[v].pred = NULL;
                    nodes[v].pred_tail = NULL;

                    add_predecessor(&nodes[v].pred, &nodes[v].pred_tail, u);
                } else if (alt_distance == nodes[v].distance) {
                    bool already_in_pred = false;
                    Predecessor *p = nodes[v].pred;
                    while (p != NULL) {
                        if (p->node == u) {
                            already_in_pred = true;
                            break;
                        }
                        p = p->next;
                    }
                    if (!already_in_pred) {
                        add_predecessor(&nodes[v].pred, &nodes[v].pred_tail, u);
                    }
                }
            }
        }
    }

    int *path_buffer = (int *)malloc(n * sizeof(int));
    int path_length = 0;

    dfs(nodes, dest, path_buffer, path_length, src, paths, graph);

    free(path_buffer);
    for (int i = 0; i < n; i++)
        free_predecessors(nodes[i].pred);
    free(nodes);
}

