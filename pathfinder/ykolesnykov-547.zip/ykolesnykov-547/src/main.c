#include "../inc/header.h"

int main(int argc, char **argv) {
    s_islandsBridgesData *data = malloc(sizeof(s_islandsBridgesData));
    if (!data) {
        memory_allocation_failed();
    }

    data->islands_indeces = NULL;
    data->bridges = NULL;
    data->number_of_islands = 0;
    data->actual_number_of_islands = 0;
    data->invalid_input = false;

    if (input_data_from_file(argc, argv, data)) {
        free_islands_bridges_data(data);
        return 1;
    }

    find_print_shortest_routes(data);
    free_islands_bridges_data(data);

    return 0;
}

