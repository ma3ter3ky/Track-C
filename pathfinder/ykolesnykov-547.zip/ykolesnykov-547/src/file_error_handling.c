#include "../inc/file_error_handling.h"

void mx_printerr(const char *s) {
    write(2, s, mx_strlen(s));
}

char *mx_strchr(const char *str, char c) {
    while (*str) {
        if (*str == c) {
            return (char *)str;
        }
        str++;
    }
    return NULL;
}


char **file_content_array(const char *filename) {
    char *file_str = mx_file_to_str(filename);
    if (file_str == NULL || mx_strlen(file_str) == 0) {
        return NULL;
    }

    int line_count = mx_count_substr(file_str, "\n") + 1;
    char **file_content = malloc((line_count + 1) * sizeof(char *));
    if (file_content == NULL) {
        free(file_str);
        return NULL;
    }

    int line_index = 0;
    char *line_start = file_str;

    while (line_start && *line_start) {
        char *next_line = mx_strchr(line_start, '\n');
        int line_length = next_line ? next_line - line_start : mx_strlen(line_start);

        file_content[line_index] = mx_strndup(line_start, line_length);
        line_index++;

        line_start = next_line ? next_line + 1 : NULL;
    }

    file_content[line_index] = NULL;
    free(file_str);
    return file_content;
}


bool invalid_number_of_comand_line_arguments(int argc) {
    if (argc != 2) {
        mx_printerr("usage: ./pathfinder [filename]\n");
        return 1;
    }
    return 0;
}

bool file_doesnot_exist(char **argv) {
    const char *filename = argv[1];
    int fd = open(filename, O_RDONLY);
    if (fd == -1) {
        mx_printerr("error: file ");
        mx_printerr(filename);
        mx_printerr(" does not exist\n");
        return 1;
    }
    close(fd);
    return 0;
}

int file_is_empty(char **argv) {
    const char *filename = argv[1];
    char *file_str = mx_file_to_str(filename);
    if (file_str == NULL) {
        return 1;
    }
    int length_of_file = mx_strlen(file_str);
    if (length_of_file == 0) {
        mx_printerr("error: file ");
        mx_printerr(filename);
        mx_printerr(" is empty\n");
        free(file_str);
        return 1;
    }
    free(file_str);
    return 0;
}


int file_error_handling(int argc, char **argv) {
    if (invalid_number_of_comand_line_arguments(argc)) {
        return 1;
    }
    if (file_doesnot_exist(argv)) {
        return 1;
    }
    if (file_is_empty(argv)) {
        return 1;
    }
    return 0;
}

