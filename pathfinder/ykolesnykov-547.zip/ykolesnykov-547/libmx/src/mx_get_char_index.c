#include "../inc/libmx.h"

int mx_get_char_index(const char *str, char c) {
    if (str == NULL) {
        return -2;
    }
    for (int cur_index = 0; str[cur_index] != '\0'; cur_index++) {
        if (str[cur_index] == c) {
            return cur_index;
        }
    }
    return -1;
}






