#include "../inc/libmx.h"

int mx_intlen(int number) {
    int length = (number <= 0) ? 1 : 0;
    while (number) {
        number /= 10;
        length++;
    }
    return length;
}

char *mx_itoa(int number) {
    int length = mx_intlen(number);

    char *result_str = malloc(length + 1);
    if (!result_str) return NULL;
    result_str[length] = '\0';

    int writing_pos = length - 1;

    if (number == 0) {
        result_str[0] = '0';
        return result_str;
    }

    bool is_negative = number < 0;
    if (is_negative) {
        result_str[0] = '-';
        if (number == INT_MIN) {
            number += 1;
            number = -number;
            result_str[writing_pos] = (char)((number % 10) + 1 + '0');
            number /= 10;
            writing_pos--;
        } else {
            number = -number;
        }
    }

    while (number != 0) {
        result_str[writing_pos] = (char)(number % 10 + '0');
        number /= 10;
        writing_pos--;
    }

    return result_str;
}

int mx_atoi(const char *str) {
    if (!str) return 0;

    int result = 0;
    int sign = 1;
    int i = 0;

    while (mx_isspace(str[i])) {
        i++;
    }

    if (str[i] == '-') {
        sign = -1;
        i++;
    } else if (str[i] == '+') {
        i++;
    }

    while (mx_isdigit(str[i])) {
        result = result * 10 + (str[i] - '0');
        i++;
    }

    return sign * result;
}

