#include "libmx.h"

bool mx_isdigit(int c) {
    return (c >= '0' && c <= '9');
}

bool mx_isalpha(int c) {
    return ('A' <= c && c <= 'Z') || ('a' <= c && c <= 'z');
}

bool mx_islower(int c) {
    return (c >= 'a' && c <= 'z');
}

unsigned long mx_hex_to_nbr(const char *hex) {
    if (hex == NULL) {
        return 0;
    }
    unsigned long return_num = 0;
    while (*hex != '\0') {
        if (mx_isdigit(*hex)) {
            return_num = return_num * 16 + (int) (*hex - '0');
        }
        else if (mx_isalpha(*hex)) {
            if (mx_islower(*hex)) {
                return_num = return_num * 16 + (int) (*hex - 'a' + 10);
            }
            else {
                return_num = return_num * 16 + (int) (*hex - 'A' + 10);
            }
        }
        else {
            return 0;
        }
        hex++;
    }
    return return_num;
}






