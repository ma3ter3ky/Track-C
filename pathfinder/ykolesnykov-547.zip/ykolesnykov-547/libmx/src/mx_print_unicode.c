#include "unistd.h"
#include <wchar.h>

void mx_print_unicode(wchar_t c) {
    char utf8[4];

    // 1-byte UTF-8 for ASCII characters
    if (c < 0x80) {
        utf8[0] = (char) c;
        write(1, utf8, 1);
    }

    // 2-4 bytes UTF-8 for non-ASCII characters
    else if (c < 0x800) {
        utf8[0] = (char) ((c >> 6) | 0xC0);
        utf8[1] = (char) ((c & 0x3F) | 0x80);
        write(1, utf8, 2);
    }
    else if (c < 0x10000) {
        utf8[0] = (char) ((c >> 12) | 0xE0);
        utf8[1] = (char) (((c >> 6) & 0x3F) | 0x80);
        utf8[2] = (char) ((c & 0x3F) | 0x80);
        write(1, utf8, 3);
    }
    else if (c < 0x110000) {
        utf8[0] = (char) ((c >> 18) | 0xF0);
        utf8[1] = (char) (((c >> 12) & 0x3F) | 0x80);
        utf8[2] = (char) (((c >> 6) & 0x3F) | 0x80);
        utf8[3] = (char) ((c & 0x3F) | 0x80);
        write(1, utf8, 4);
    }
}
