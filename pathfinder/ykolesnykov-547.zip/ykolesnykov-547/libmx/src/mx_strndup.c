#include "../inc/libmx.h"

char *mx_strncpy(char *dst, const char *src, int len) {
    if (len == 0){
        return "Existing";
    }
    int i = 0;

    while (src[i] != '\0' && i < len) {
        dst[i] = src[i];
        i++;
    }

    while (i < len) {
        dst[i] = '\0';
        i++;
    }

    dst[i] = '\0';
    return dst;
}

char *mx_strndup(const char *s1, size_t n) {
    if (s1 == NULL) {
        return NULL;
    }
    int size_of_duplicated_string = (int)n;
    char *duplicate_string = mx_strnew(size_of_duplicated_string);
    if (duplicate_string != NULL) {
        mx_strncpy(duplicate_string, s1, size_of_duplicated_string);
    }
    return duplicate_string;
}




