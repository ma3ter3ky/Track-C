#include "../inc/libmx.h"

int mx_strlen(const char *s) {
    int length = 0;

    while (s[length] != '\0') {
        length++;
    }
    return length;
}

void mx_printstr(const char *s) {
    if (!s) {
        return;
    }
    write(1, s, mx_strlen(s));
}
