#include "../inc/libmx.h"

int mx_read_line(char **lineptr, size_t buf_size, char delim, const int fd) {
    if (!lineptr || fd < 0 || buf_size <= 0) {
        return -2;
    }

    static char buffer[1024];
    static ssize_t buffer_size = 0;
    static int buffer_index = 0;

    int total_bytes_read = 0;
    char *result = mx_strnew(0);

    while (1) {
        if (buffer_size == 0 || buffer_index >= buffer_size) {
            buffer_size = read(fd, buffer, sizeof(buffer));
            buffer_index = 0;

            if (buffer_size == 0) {
                if (total_bytes_read > 0) {
                    *lineptr = result;
                    return total_bytes_read;
                } else {
                    mx_strdel(&result);
                    return -1;
                }
            }

            if (buffer_size < 0) {
                mx_strdel(&result);
                return -2;
            }
        }

        while (buffer_index < buffer_size) {
            char ch = buffer[buffer_index++];

            if (ch == delim) {
                *lineptr = result;
                return total_bytes_read;
            }

            char *new_result = malloc(total_bytes_read + 2);
            if (!new_result) {
                mx_strdel(&result);
                return -2;
            }

            if (total_bytes_read > 0) {
                mx_strncpy(new_result, result, total_bytes_read);
            }
            new_result[total_bytes_read] = ch;
            new_result[total_bytes_read + 1] = '\0';

            mx_strdel(&result);
            result = new_result;

            total_bytes_read++;
        }
    }
}







