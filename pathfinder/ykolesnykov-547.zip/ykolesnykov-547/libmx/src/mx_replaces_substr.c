#include "../inc/libmx.h"

char *mx_replace_substr(const char *str, const char *sub, const char *replace) {
    if (str == NULL || sub == NULL || replace == NULL) {
        return NULL;
    }

    int number_of_replaces = mx_count_substr(str, sub);

    if (number_of_replaces == 0) {
        return mx_strdup(str);
    }

    int res_str_size = mx_strlen(str) + number_of_replaces * (mx_strlen(replace) - mx_strlen(sub)) + 1;
    char *result_string = mx_strnew(res_str_size);

    if (!result_string) {
        return NULL;
    }

    int index = 0, res_str_index = 0;
    while (str[index] != '\0') {
        int next_substr_index = mx_get_substr_index(&str[index], sub) + index;
        /*mx_printint(next_substr_index);
        mx_printstr(" - next substr index\n");*/

        if (next_substr_index == -1) {
            /*mx_printstr("!Next substring index = -1, copying the string and break!\n");*/
            mx_strcpy(&result_string[res_str_index], &str[index]);
            break;
        }

        while (index < next_substr_index) {
            /*mx_printchar(str[index]);
            mx_printstr(" - copied char\n");*/
            result_string[res_str_index++] = str[index++];
        }

        mx_strncpy(&result_string[res_str_index], replace, mx_strlen(replace));
        res_str_index += mx_strlen(replace);
        index += mx_strlen(sub);

    }

    result_string[res_str_size] = '\0';
    return result_string;
}










