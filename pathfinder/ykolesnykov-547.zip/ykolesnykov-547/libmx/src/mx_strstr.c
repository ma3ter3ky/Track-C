#include "../inc/libmx.h"

char *mx_strchr(const char *s, int c) {
    while (*s != c) {
        if (*s == '\0') {
            return c == '\0' ? (char *) s : NULL;
        }
        s++;
    }
    return (char *) s;
}

int mx_strncmp(const char *s1, const char *s2, int n) {
    int iterator = 0;
    while ((s1[iterator] != '\0' || s2[iterator] != '\0') && (iterator < n)) {
        if (s1[iterator] != s2[iterator]) {
            return s1[iterator] - s2[iterator];
        }
        iterator++;
    }
    return 0;
}

char *mx_strstr(const char *s1, const char *s2) {
    int length_of_s2 = mx_strlen(s2);
    while (mx_strchr(s1, s2[0]) != NULL) {
        if (mx_strncmp(s1, s2, length_of_s2) == 0) {
            return (char *) s1;
        }
        s1++;
    }
    return 0;
}






