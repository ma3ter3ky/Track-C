#include "../inc/libmx.h"

void LPS_array(const char *sub, int *lps, int len_sub) {
    lps[0] = 0;
    int j = 0, i = 1;
    while (i < len_sub) {
        if (sub[i] != sub[j]) {
            if (j == 0) {
                lps[i] = 0;
                i++;
            }
            else {
                j = lps[j - 1];
            }
        }
        else {
            lps[i] = j + 1;
            j++;
            i++;
        }
    }
}

int KMP(const char *str, const char *sub) {
    int len_str = mx_strlen(str);
    int len_sub = mx_strlen(sub);

    int lps[len_sub];
    LPS_array(sub, lps, len_sub);

    int str_index = 0, sub_index = 0;

    while (str_index < len_str) {
        if (str[str_index] == sub[sub_index]) {
            str_index++;
            sub_index++;
        }
        if (sub_index == len_sub) {
            return str_index - sub_index;
        }
        else if (str_index < len_str && str[str_index] != sub[sub_index]) {
            if (sub_index != 0) {
                sub_index = lps[sub_index - 1];
            }
            else {
                str_index++;
            }
        }
    }
    return -1;
}

int mx_get_substr_index(const char *str, const char *sub) {
    if (str == NULL || sub == NULL) {
        return -2;
    }

    return KMP(str, sub);
}





