#include "../inc/libmx.h"
 void print_array(char **arr, int size) {
    printf("Sorted array: ");
    for (int i = 0; i < size; i++) {
        printf("%s ", arr[i]);
    }
    printf("\n");
}

/*// Тестовый случай 1
static void test_case_1(void) {
    char *arr[] = {"Michelangelo", "Donatello", "Leonardo", "Raphael"};
    int size = 4;

    int swap_count = mx_quicksort(arr, 0, size - 1);
    printf("Number of swaps: %d\n", swap_count);
    print_array(arr, size);
}

// Тестовый случай 2
static void test_case_2(void) {
    char *arr[] = {"DMC", "Clint Eastwood", "Dr Brown", "Einstein", "Jessica", "Biff Tannen"};
    int size = 6;

    int swap_count = mx_quicksort(arr, 0, size - 1);
    printf("Number of swaps: %d\n", swap_count);
    print_array(arr, size);
}*/
/*int main() {
    test_case_1();
    printf("\n\n");
    test_case_2();
    return 0;
}*/








