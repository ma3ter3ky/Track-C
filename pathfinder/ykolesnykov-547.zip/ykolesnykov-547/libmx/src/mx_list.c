#include "../inc/libmx.h"

t_list *mx_create_node(void *data) {
    t_list *root = malloc(sizeof(t_list));
    root->data = data;
    root->next = NULL;
    return root;
}

void mx_push_front(t_list **list, void *data) {
    if (*list == NULL) {
        *list = mx_create_node(data);
        return;
    }
    t_list *new_node = mx_create_node(data);
    new_node->next = *list;
    *list = new_node;
}

void mx_push_back(t_list **list, void *data) {
    if (*list == NULL) {
        *list = mx_create_node(data);
        return;
    }
    t_list *new_node = malloc(sizeof(t_list));
    new_node->data = data;

    t_list *curr = *list;
    while (curr->next!= NULL) {
        curr = curr->next;
    }
    curr->next = new_node;
}

void mx_pop_front(t_list **list) {
    if (*list == NULL) {
        return;
    }
    if ((*list)->next == NULL) {
        free(*list);
        *list = NULL;
        return;
    }
    t_list *curr = *list;
    *list = curr->next;
    free(curr);
}

void mx_pop_back(t_list **list) {
    if (*list == NULL) {
        return;
    }
    if ((*list)->next == NULL) {
        free(*list);
        *list = NULL;
        return;
    }
    t_list *curr = *list;
    while (curr->next->next != NULL) {
        curr = curr->next;
    }
    free(curr->next);
    curr->next = NULL;
}

int mx_list_size(t_list *list) {
    if (list == NULL) {
        return 0;
    }
    int size_of_list = 0;
    for (t_list *curr = list; curr != NULL; curr = curr->next) {
        size_of_list++;
    }
    return size_of_list;
}
