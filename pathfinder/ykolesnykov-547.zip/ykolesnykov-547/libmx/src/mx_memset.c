#include "../inc/libmx.h"

void *mx_memset(void *b, int c, size_t len) {
    if (b == NULL){
        return NULL;
    }

    for (size_t i = 0; i < len; i++) {
        ((char*)b)[i] = (char)c;
    }
    return b;
}







