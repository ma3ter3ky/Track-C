#include "../inc/libmx.h"

t_list *mx_sort_list(t_list *list, bool (*cmp)(void *, void *)) {
    if (list == NULL || cmp == NULL)
        return NULL;

    int size_of_list = mx_list_size(list);

    for (int i = 0; i < size_of_list - 1; i++) {
        t_list *element = list;
        for (int j = 0; j < size_of_list - i - 1; j++) {
            if (cmp(element->data, element->next->data)) {
                void *data = element->data;
                element->data = element->next->data;
                element->next->data = data;
            }
            element = element->next;
        }
    }
    return list;
}








