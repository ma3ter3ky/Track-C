#include "../inc/libmx.h"

void mx_swap_strings(char **a, char **b) {
    char *temp = *a;
    *a = *b;
    *b = temp;
}

int mx_compare_str_by_length(const char *string1, const char *string2) {
    return (mx_strlen(string1) - mx_strlen(string2));
}

static int partition(char **arr, int left, int right, int *swap_counter) {
    if (right - left < 1) return 0;
    int mid = (left + right) / 2;
    char *pivot = arr[mid];
    int smaller_pivot = left;
    for (int greater_pivot = right; greater_pivot > smaller_pivot;) {
        if (mx_compare_str_by_length(arr[smaller_pivot], pivot) >= 0) {
            if (mx_compare_str_by_length(arr[greater_pivot], pivot) < 0) {
                mx_swap_strings(&arr[smaller_pivot], &arr[greater_pivot]);
                (*swap_counter)++;
                smaller_pivot++;
                greater_pivot--;
            } else {
                greater_pivot--;
            }
        } else {
            smaller_pivot++;
        }
    }
    return smaller_pivot;
}

int mx_quicksort(char **arr, int left, int right) {
    if (!arr) return -1;

    int swap_counter = 0;
    if (left < right) {
        int pivot_index = partition(arr, left, right, &swap_counter);

        swap_counter += mx_quicksort(arr, left, pivot_index - 1);
        swap_counter += mx_quicksort(arr, pivot_index + 1, right);
    }
    return swap_counter;
}
