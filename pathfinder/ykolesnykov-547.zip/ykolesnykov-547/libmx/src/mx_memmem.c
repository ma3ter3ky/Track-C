#include "../inc/libmx.h"

void memmem_LPS_array(const unsigned char *sub, int *lps, size_t sublen) {
    lps[0] = 0;
    int j = 0;
    for (size_t i = 1; i < sublen;) {
        if (sub[i] == sub[j]) {
            j++;
            lps[i] = j;
            i++;
        } else {
            if (j != 0) {
                j = lps[j - 1];
            } else {
                lps[i] = 0;
                i++;
            }
        }
    }
}

void *mx_memmem(const void *big, size_t big_len, const void *little, size_t little_len) {
    if (!big || !little || little_len == 0 || little_len > big_len) {
        return NULL;
    }

    const unsigned char *str = (const unsigned char *)big;
    const unsigned char *sub = (const unsigned char *)little;

    int lps[little_len];
    memmem_LPS_array(sub, lps, little_len);

    size_t i = 0;
    size_t j = 0;

    while (i < big_len) {
        if (str[i] == sub[j]) {
            i++;
            j++;
        }

        if (j == little_len) {
            return (void *)(str + i - j);
        }

        if (i < big_len && str[i] != sub[j]) {
            if (j != 0) {
                j = lps[j - 1];
            } else {
                i++;
            }
        }
    }

    return NULL;
}
