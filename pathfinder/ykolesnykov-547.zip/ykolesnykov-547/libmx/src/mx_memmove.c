#include "../inc/libmx.h"

void *mx_memmove(void *dst, const void *src, size_t len) {
    unsigned char *temp_storage = malloc(len);

    if (temp_storage == NULL) {
        return NULL;
    }

    mx_memcpy(temp_storage, src, len);
    mx_memcpy(dst, temp_storage, len);

    free(temp_storage);
    return dst;
}
