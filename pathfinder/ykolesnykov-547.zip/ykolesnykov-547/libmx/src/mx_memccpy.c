#include "../inc/libmx.h"

void *mx_memccpy(void *restrict dst, const void *restrict src, int c, size_t n) {
    if (dst == NULL || src == NULL) {
        return NULL;
    }
    unsigned char *dst_char = (unsigned char *)dst;
    const unsigned char *src_char = (const unsigned char *)src;
    const unsigned char end_char = (const unsigned char) c;

    for (size_t i = 0; i < n; i++) {
        dst_char[i] = src_char[i];

        if (src_char[i] == end_char) {
            return (&dst_char[i + 1]);
        }
    }
    return NULL;
}




