#include "../inc/libmx.h"

int mx_bubble_sort(char **arr, int size) {
    int number_of_swaps = 0;
    for (int element1 = 0; element1 < size - 1; element1++) {
        for (int element2 = element1 + 1; element2 < size; element2++) {
            if (mx_strcmp(arr[element1], arr[element2]) > 0) {
                char *tmp = arr[element1];
                arr[element1] = arr[element2];
                arr[element2] = tmp;
                number_of_swaps++;
            }
        }
    }
    return number_of_swaps;
}
