#pragma once
#include "header.h"


void print_shortest_route(int **dist, t_int_list ***next, int start, int end, s_islandsBridgesData *data);
void print_all_routes(int **dist, t_int_list ***next, s_islandsBridgesData *data);
void find_print_shortest_routes(s_islandsBridgesData *data);

