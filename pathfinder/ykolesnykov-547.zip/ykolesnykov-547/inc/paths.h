#ifndef PATHS_H
#define PATHS_H

#include "header.h"

Paths *create_paths();
void add_path(Paths *paths, int *nodes, int length);
void free_paths(Paths *paths);

#endif // PATHS_H
