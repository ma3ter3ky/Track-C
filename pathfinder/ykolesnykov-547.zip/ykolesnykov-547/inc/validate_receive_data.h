#pragma once

#include "header.h"

void memory_allocation_failed();
bool validate_receive_data(char **file_content, s_islandsBridgesData *data);
void free_islands_bridges_data(s_islandsBridgesData *data);

