#pragma once

#include "header.h"

int input_data_from_file(int argc, char **argv, s_islandsBridgesData *data);






