#pragma once

#include "header.h"

bool validate_first_line(s_islandsBridgesData *data, const char *line);

