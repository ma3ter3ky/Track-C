#ifndef DIJKSTRA_H
#define DIJKSTRA_H

#include "header.h"

void find_all_shortest_paths(Graph *graph, int src, int dest, Paths *paths);

#endif
