#pragma once

#include "header.h"

t_int_list *create_list_with_node(int node);
void free_list(t_int_list *list);
t_int_list *copy_list(t_int_list *src);
void merge_lists_in_place(t_int_list **list1, t_int_list *list2);
int list_contains(t_int_list *list, int node);



