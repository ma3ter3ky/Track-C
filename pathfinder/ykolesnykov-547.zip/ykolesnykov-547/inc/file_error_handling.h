#pragma once

#include "header.h"

int file_error_handling(int argc, char **argv);
void mx_printerr(const char *s);
char **file_content_array(const char *filename);




