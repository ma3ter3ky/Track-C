#pragma once

#include "header.h"

bool parse_islands_and_bridges(s_islandsBridgesData *data, char **file_content);
