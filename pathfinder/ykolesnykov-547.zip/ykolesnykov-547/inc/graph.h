#ifndef GRAPH_H
#define GRAPH_H

#include "header.h"

Graph *create_graph(int num_nodes, int **adj_matrix, char **islands);
void free_graph(Graph *graph);

#endif






