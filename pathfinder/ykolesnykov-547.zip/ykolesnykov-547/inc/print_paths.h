#ifndef PRINT_PATHS_H
#define PRINT_PATHS_H

#include "graph.h"
#include "paths.h"

void print_paths(Graph *graph, int src, int dest, Paths *paths);

#endif // PRINT_PATHS_H
