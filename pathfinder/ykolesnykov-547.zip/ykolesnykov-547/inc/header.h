#pragma once

#include "../libmx/inc/libmx.h"

typedef struct {
    int number_of_islands;
    int actual_number_of_islands;
    int number_of_bridges;

    char **islands_indeces;
    int **bridges;

    bool invalid_input;
} s_islandsBridgesData;

typedef struct s_int_list {
    int node;
    struct s_int_list *next;
} t_int_list;

typedef struct {
    int num_nodes;
    int **adj_matrix;
    char **islands;
} Graph;

typedef struct Path {
    int *nodes;
    int length;
    struct Path *next;
} Path;

typedef struct Paths {
    Path *head;
    Path *tail;
} Paths;

#include "file_error_handling.h"
#include "input_data_from_file.h"
#include "validate_receive_data.h"
#include "validate_first_line.h"
#include "find_the_shortest_route.h"
#include "new_list_functions.h"
#include "dijkstra.h"
#include "graph.h"
#include "print_paths.h"
#include "paths.h"

#include "parse_islands_and_bridges.h"


